"""
OpportunityLab Results Panel
"""

import customtkinter as ctk


class ResultsPanel(ctk.CTkFrame):

    def __init__(self, master, on_selected=None):

        super().__init__(master)

        self.on_selected = on_selected
        self.cards = []

        self.build_ui()

    def build_ui(self):

        title = ctk.CTkLabel(
            self,
            text="Search Results",
            font=("Segoe UI", 18, "bold")
        )

        title.pack(anchor="w", padx=10, pady=(10, 5))

        self.results_list = ctk.CTkScrollableFrame(self)

        self.results_list.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=(0, 10)
        )

    def clear(self):

        for widget in self.results_list.winfo_children():
            widget.destroy()

        self.cards.clear()

    def score_colour(self, score):

        if score >= 90:
            return "#2ECC71"

        if score >= 75:
            return "#3498DB"

        if score >= 50:
            return "#F1C40F"

        return "#E74C3C"

    def add_opportunity(self, opportunity):

        card = ctk.CTkFrame(
            self.results_list,
            cursor="hand2"
        )

        card.pack(
            fill="x",
            padx=5,
            pady=5
        )

        badge = ctk.CTkLabel(
            card,
            text=str(opportunity.score),
            width=45,
            fg_color=self.score_colour(opportunity.score),
            corner_radius=8,
            text_color="white",
            font=("Segoe UI", 14, "bold")
        )

        badge.pack(
            side="left",
            padx=10,
            pady=10
        )

        title = ctk.CTkLabel(
            card,
            text=opportunity.title,
            anchor="w",
            justify="left",
            wraplength=300
        )

        title.pack(
            side="left",
            fill="x",
            expand=True,
            padx=5
        )

        for widget in (card, badge, title):

            widget.bind(
                "<Button-1>",
                lambda e, o=opportunity: self.select(o)
            )

        self.cards.append(card)

    def select(self, opportunity):

        if self.on_selected:

            self.on_selected(opportunity)