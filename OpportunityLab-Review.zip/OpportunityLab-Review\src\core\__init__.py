"""
Core module for OpportunityLab.
"""